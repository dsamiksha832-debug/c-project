#pragma once
#include "Detector.h"
#include <string>
#include <vector>
using namespace std;

// ─────────────────────────────────────────────────────────
//  CLASS: Question
//  Encapsulates one quiz question + its weight
// ─────────────────────────────────────────────────────────
class Question {
private:
    string text;
    int    weight;    // importance multiplier (1 or 2)
    int    answer;    // user's answer 1–5

public:
    Question(const string& t, int w = 1)
        : text(t), weight(w), answer(0) {}

    // Ask question, store & return weighted score
    int ask(int index);

    int getWeightedScore() const { return answer * weight; }
    int getMaxScore()      const { return 5 * weight; }
    string getText()       const { return text; }
};


// ─────────────────────────────────────────────────────────
//  CLASS: QuizDetector  (inherits Detector)
//  Text-based mood detection through questionnaire
// ─────────────────────────────────────────────────────────
class QuizDetector : public Detector {
private:
    vector<Question> questions;
    int totalScore;
    int maxPossible;

    string mapScoreToEmotion(float ratio) const;

public:
    QuizDetector();
    ~QuizDetector() override {}

    void   run()           override;
    string getEmotion()    override;
    void   displayResult() override;
};
