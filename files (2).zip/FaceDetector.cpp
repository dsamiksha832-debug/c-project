#include "FaceDetector.h"
#include <iostream>
using namespace std;
using namespace cv;

// ─── Constructor ──────────────────────────────────────────
FaceDetector::FaceDetector()
    : smileDetected(false), eyesDetected(0), faceFound(false) {}

// ─── Destructor ───────────────────────────────────────────
FaceDetector::~FaceDetector() {
    if (camera.isOpened())
        camera.release();
    destroyAllWindows();
}

// ─── loadCascades ─────────────────────────────────────────
bool FaceDetector::loadCascades(const string& faceXML,
                                 const string& smileXML,
                                 const string& eyeXML) {
    if (!faceCascade.load(faceXML)) {
        cerr << "  [ERROR] Cannot load face cascade: " << faceXML << endl;
        return false;
    }
    if (!smileCascade.load(smileXML)) {
        cerr << "  [ERROR] Cannot load smile cascade: " << smileXML << endl;
        return false;
    }
    if (!eyeCascade.load(eyeXML)) {
        cerr << "  [ERROR] Cannot load eye cascade: " << eyeXML << endl;
        return false;
    }
    return true;
}


// ─── inferEmotion ─────────────────────────────────────────
// Simple rule-based heuristic from detected features
string FaceDetector::inferEmotion() const {
    if (!faceFound)
        return "Unknown (No Face)";

    if (smileDetected && eyesDetected >= 2)
        return "Very Happy";
    else if (smileDetected && eyesDetected == 1)
        return "Happy";
    else if (!smileDetected && eyesDetected >= 2)
        return "Neutral";
    else if (!smileDetected && eyesDetected == 1)
        return "Sad";
    else
        return "Very Sad";
}


// ─── drawOverlay ──────────────────────────────────────────
void FaceDetector::drawOverlay(Mat& img,
                                const vector<Rect>& faces,
                                const vector<Rect>& smiles,
                                const vector<Rect>& eyes) {
    // Draw face rectangles
    for (const auto& f : faces) {
        rectangle(img, f, Scalar(0, 255, 0), 2);
        putText(img, "Face", Point(f.x, f.y - 8),
                FONT_HERSHEY_SIMPLEX, 0.6, Scalar(0, 255, 0), 2);
    }
    // Draw smile rectangles (relative to face)
    for (const auto& s : smiles) {
        rectangle(img, s, Scalar(255, 165, 0), 2);
    }
    // Draw eye rectangles
    for (const auto& e : eyes) {
        Point centre(e.x + e.width / 2, e.y + e.height / 2);
        circle(img, centre, e.width / 2, Scalar(255, 0, 0), 2);
    }

    // Emotion label at top-left
    string label = "Emotion: " + detectedEmotion;
    putText(img, label, Point(10, 30),
            FONT_HERSHEY_DUPLEX, 0.9, Scalar(0, 220, 255), 2);

    // Press Q hint
    putText(img, "Press Q to capture & continue",
            Point(10, img.rows - 15),
            FONT_HERSHEY_SIMPLEX, 0.55, Scalar(200, 200, 200), 1);
}


// ─── run ──────────────────────────────────────────────────
void FaceDetector::run() {
    cout << "\n  [Face Detector] Opening camera..." << endl;

    camera.open(0);   // 0 = default webcam
    if (!camera.isOpened()) {
        cerr << "  [ERROR] Cannot access camera." << endl;
        detectedEmotion = "Unknown";
        confidenceScore = 0;
        return;
    }

    cout << "  Camera ready. A window will open." << endl;
    cout << "  Look at the camera, then press 'Q' to capture.\n" << endl;

    Mat gray;
    vector<Rect> faces, smiles, eyes, allEyes;

    while (true) {
        camera >> frame;
        if (frame.empty()) break;

        cvtColor(frame, gray, COLOR_BGR2GRAY);
        equalizeHist(gray, gray);

        // ── Detect faces ──────────────────────────────────
        faceCascade.detectMultiScale(
            gray, faces,
            1.1, 5, 0,
            Size(120, 120)
        );

        smiles.clear();
        allEyes.clear();
        smileDetected = false;
        eyesDetected  = 0;
        faceFound     = !faces.empty();

        for (const auto& face : faces) {
            Mat faceROI  = gray(face);
            Mat colorROI = frame(face);

            // ── Detect smiles inside face ──────────────
            vector<Rect> localSmiles;
            smileCascade.detectMultiScale(
                faceROI, localSmiles,
                1.8, 20, 0,
                Size(25, 25)
            );
            for (auto& s : localSmiles)
                smiles.push_back(Rect(face.x + s.x,
                                     face.y + s.y, s.width, s.height));
            if (!localSmiles.empty())
                smileDetected = true;

            // ── Detect eyes inside face ────────────────
            // Only search in upper 60% of face
            Rect upperFace(0, 0, face.width, (int)(face.height * 0.6));
            Mat  eyeROI = faceROI(upperFace);

            vector<Rect> localEyes;
            eyeCascade.detectMultiScale(
                eyeROI, localEyes,
                1.1, 10, 0,
                Size(20, 20)
            );
            for (auto& e : localEyes)
                allEyes.push_back(Rect(face.x + e.x,
                                      face.y + e.y, e.width, e.height));
            eyesDetected = (int)localEyes.size();
            if (eyesDetected > 2) eyesDetected = 2;
        }

        // Update emotion live
        detectedEmotion = inferEmotion();

        // Draw overlay & show
        drawOverlay(frame, faces, smiles, allEyes);
        imshow("Emotion Detector - Face View", frame);

        // Q to quit and capture
        if (waitKey(30) == 'q' || waitKey(30) == 'Q')
            break;
    }

    // Final capture
    detectedEmotion = inferEmotion();
    confidenceScore = faceFound ? 75 : 0;
    // Adjust confidence if both cues present
    if (smileDetected && eyesDetected >= 2) confidenceScore = 90;

    camera.release();
    destroyAllWindows();
}


// ─── getEmotion ───────────────────────────────────────────
string FaceDetector::getEmotion() {
    return detectedEmotion;
}


// ─── displayResult ────────────────────────────────────────
void FaceDetector::displayResult() {
    cout << "\n  [Face Detection Result]";
    cout << "\n  Detected : " << detectedEmotion;
    cout << "\n  Smile    : " << (smileDetected ? "Yes" : "No");
    cout << "\n  Eyes     : " << eyesDetected << " detected";
    cout << "\n  Confidence: " << confidenceScore << "%\n";
}
