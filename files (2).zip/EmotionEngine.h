#pragma once
#include "Detector.h"
#include <string>
#include <map>
#include <memory>
#include <vector>
using namespace std;

// ─────────────────────────────────────────────────────────
//  CLASS: EmotionProfile
//  Stores info about a single emotion state
// ─────────────────────────────────────────────────────────
class EmotionProfile {
private:
    string name;
    string emoji;
    string advice;
    string color;    // ANSI color code for terminal

public:
    EmotionProfile(const string& n, const string& em,
                   const string& adv, const string& col)
        : name(n), emoji(em), advice(adv), color(col) {}

    void print() const;
    string getName() const { return name; }
};


// ─────────────────────────────────────────────────────────
//  CLASS: EmotionEngine
//  Aggregates results from multiple Detector objects.
//  Uses polymorphism — holds vector<Detector*>
// ─────────────────────────────────────────────────────────
class EmotionEngine {
private:
    string                              userName;
    vector<Detector*>                   detectors;    // polymorphic collection
    map<string, EmotionProfile*>        profiles;

    string fuseEmotions(const vector<string>& emotions) const;
    void   buildProfiles();

public:
    EmotionEngine();
    ~EmotionEngine();

    void setUser(const string& name) { userName = name; }

    // Add any Detector subclass (polymorphism)
    void addDetector(Detector* d) { detectors.push_back(d); }

    void runAll();
    void showFinalReport() const;
};
