#pragma once
#include <string>
using namespace std;

// ─────────────────────────────────────────────────────────
//  ABSTRACT BASE CLASS: Detector
//  All detection modes inherit from this.
//  Uses pure virtual functions → polymorphism.
// ─────────────────────────────────────────────────────────
class Detector {
protected:
    string detectedEmotion;
    int    confidenceScore;   // 0–100

public:
    Detector() : detectedEmotion("Unknown"), confidenceScore(0) {}
    virtual ~Detector() {}

    // Pure virtual — every subclass MUST implement these
    virtual void   run()          = 0;
    virtual string getEmotion()   = 0;
    virtual void   displayResult()= 0;

    // Concrete (shared) helper
    int getConfidence() const { return confidenceScore; }
};
