#include "EmotionEngine.h"
#include <iostream>
#include <algorithm>
using namespace std;

// ANSI color codes
#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define CYAN    "\033[36m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"
#define RED     "\033[31m"
#define MAGENTA "\033[35m"

// ─── EmotionProfile::print ────────────────────────────────
void EmotionProfile::print() const {
    cout << color << BOLD;
    cout << "\n  ╔══════════════════════════════════════════╗";
    cout << "\n  ║  " << emoji << "  Emotion  : " << name;
    string spaces(34 - (int)name.size(), ' ');
    cout << spaces << "║";
    cout << "\n  ║  Advice   : ";
    // Word-wrap advice at ~30 chars
    int lineLen = 0;
    for (char c : advice) {
        cout << c;
        if (++lineLen > 28 && c == ' ') {
            cout << "\n  ║             ";
            lineLen = 0;
        }
    }
    cout << "\n  ╚══════════════════════════════════════════╝";
    cout << RESET << endl;
}


// ─── EmotionEngine constructor ────────────────────────────
EmotionEngine::EmotionEngine() {
    buildProfiles();
}

void EmotionEngine::buildProfiles() {
    profiles["Very Sad"]   = new EmotionProfile(
        "Very Sad",   "(T_T)",
        "Take a break. Talk to someone you trust. You are not alone.",
        BLUE);

    profiles["Sad"]        = new EmotionProfile(
        "Sad",        "( ; ; )",
        "Try music or a short walk. Things will get better.",
        CYAN);

    profiles["Neutral"]    = new EmotionProfile(
        "Neutral",    "( - . - )",
        "A steady day! Try something creative to lift your spirits.",
        YELLOW);

    profiles["Happy"]      = new EmotionProfile(
        "Happy",      "( ^ u ^ )",
        "Great mood! Spread the positivity around you.",
        GREEN);

    profiles["Very Happy"] = new EmotionProfile(
        "Very Happy", "( ★ v ★ )",
        "You are on fire! Keep up the amazing energy!",
        MAGENTA);
}


// ─── Destructor ───────────────────────────────────────────
EmotionEngine::~EmotionEngine() {
    for (auto& p : profiles) delete p.second;
    // Note: detectors are owned by main — not deleted here
}


// ─── runAll ───────────────────────────────────────────────
void EmotionEngine::runAll() {
    cout << BOLD << CYAN;
    cout << "\n  ╔══════════════════════════════════════════╗";
    cout << "\n  ║     EMOTION DETECTOR  — Starting...      ║";
    cout << "\n  ╚══════════════════════════════════════════╝";
    cout << RESET << "\n";

    for (Detector* d : detectors) {
        d->run();           // polymorphic call
        d->displayResult(); // polymorphic call
    }
}


// ─── fuseEmotions ─────────────────────────────────────────
// Weighted majority — give more weight to face (index 1 if present)
string EmotionEngine::fuseEmotions(const vector<string>& emotions) const {
    const vector<string> order = {
        "Very Sad", "Sad", "Neutral", "Happy", "Very Happy"
    };

    // Convert emotion names to scores
    map<string, int> scoreMap = {
        {"Very Sad", 1}, {"Sad", 2}, {"Neutral", 3},
        {"Happy", 4},    {"Very Happy", 5}
    };

    float total = 0, weight = 0;
    for (int i = 0; i < (int)emotions.size(); i++) {
        float w = (i == 0) ? 1.0f : 1.5f;   // face gets more weight
        if (scoreMap.count(emotions[i])) {
            total  += scoreMap.at(emotions[i]) * w;
            weight += w;
        }
    }

    if (weight == 0) return "Neutral";

    int avg = (int)round(total / weight);
    avg = max(1, min(5, avg));
    return order[avg - 1];
}


// ─── showFinalReport ──────────────────────────────────────
void EmotionEngine::showFinalReport() const {
    vector<string> results;
    for (Detector* d : detectors)
        results.push_back(d->getEmotion());

    string fused = fuseEmotions(results);

    cout << BOLD << "\n\n  ════ FINAL REPORT FOR: " << userName
         << " ════" << RESET;

    cout << "\n\n  Individual readings:";
    for (int i = 0; i < (int)detectors.size(); i++) {
        cout << "\n    [" << (i == 0 ? "Quiz" : "Face") << "] "
             << detectors[i]->getEmotion()
             << "  (confidence " << detectors[i]->getConfidence() << "%)";
    }

    if (profiles.count(fused))
        profiles.at(fused)->print();
    else
        cout << "\n  Could not determine emotion clearly.\n";
}
