/*
 * ═══════════════════════════════════════════════════════════
 *   EMOTION DETECTOR — C++ Project
 *   Concepts: Inheritance, Polymorphism, Abstract Classes,
 *             Virtual Functions, Encapsulation, STL (vector,
 *             map), Dynamic Memory, OpenCV Integration
 *
 *   Classes:
 *     Detector (abstract base)
 *       ├── QuizDetector   (text questionnaire)
 *       └── FaceDetector   (OpenCV camera)
 *     Question
 *     EmotionProfile
 *     EmotionEngine        (aggregator/fusioner)
 * ═══════════════════════════════════════════════════════════
 */

#include <iostream>
#include <string>
#include "EmotionEngine.h"
#include "QuizDetector.h"
#include "FaceDetector.h"
using namespace std;

// Haar cascade XML paths — update if installed elsewhere
const string FACE_CASCADE  = "/usr/share/opencv4/haarcascades/haarcascade_frontalface_default.xml";
const string SMILE_CASCADE = "/usr/share/opencv4/haarcascades/haarcascade_smile.xml";
const string EYE_CASCADE   = "/usr/share/opencv4/haarcascades/haarcascade_eye.xml";

int main() {
    // ── Intro ────────────────────────────────────────────
    cout << "\n  Welcome to the Emotion Detector!\n";
    cout << "  Enter your name: ";
    string name;
    cin >> name;

    // ── Create engine ─────────────────────────────────────
    EmotionEngine engine;
    engine.setUser(name);

    // ── Create detectors (polymorphic objects) ────────────
    QuizDetector* quiz = new QuizDetector();
    FaceDetector* face = new FaceDetector();

    // Try to load Haar cascades; skip face detection if unavailable
    bool faceReady = face->loadCascades(FACE_CASCADE, SMILE_CASCADE, EYE_CASCADE);

    // ── Register detectors (polymorphism via base pointer) ─
    engine.addDetector(quiz);
    if (faceReady)
        engine.addDetector(face);
    else
        cout << "  [Note] Face detection unavailable (cascade files not found).\n"
             << "         Running quiz-only mode.\n";

    // ── Run all detectors & show report ───────────────────
    engine.runAll();
    engine.showFinalReport();

    // ── Cleanup ───────────────────────────────────────────
    delete quiz;
    delete face;

    cout << "\n  Thank you, " << name << ". Take care!\n\n";
    return 0;
}
