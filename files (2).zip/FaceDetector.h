#pragma once
#include "Detector.h"
#include <opencv2/opencv.hpp>
#include <opencv2/objdetect.hpp>
#include <string>
using namespace std;
using namespace cv;

// ─────────────────────────────────────────────────────────
//  CLASS: FaceDetector  (inherits Detector)
//  Uses OpenCV + Haar Cascade to detect face features.
//
//  Emotion heuristics applied:
//   • Smile cascade  → joy/happiness
//   • Eye detection  → alertness / openness
//   • Face region ratio → fatigue / sadness
// ─────────────────────────────────────────────────────────
class FaceDetector : public Detector {
private:
    CascadeClassifier faceCascade;
    CascadeClassifier smileCascade;
    CascadeClassifier eyeCascade;

    VideoCapture camera;
    Mat          frame;

    // Analysis state
    bool smileDetected;
    int  eyesDetected;   // 0, 1, or 2
    bool faceFound;

    string inferEmotion() const;
    void   drawOverlay(Mat& img,
                       const vector<Rect>& faces,
                       const vector<Rect>& smiles,
                       const vector<Rect>& eyes);

public:
    FaceDetector();
    ~FaceDetector() override;

    bool loadCascades(const string& faceXML,
                      const string& smileXML,
                      const string& eyeXML);

    void   run()           override;
    string getEmotion()    override;
    void   displayResult() override;
};
