#include "QuizDetector.h"
#include <iostream>
#include <iomanip>
using namespace std;

// ─── Question::ask ───────────────────────────────────────
int Question::ask(int index) {
    cout << "\n  [Q" << index << "] " << text << endl;
    cout << "       1=Not at all   2=Slightly   3=Moderate   4=Quite   5=Absolutely\n";
    cout << "       Your answer: ";

    int val;
    while (!(cin >> val) || val < 1 || val > 5) {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "       Please enter 1–5: ";
    }
    answer = val;
    return getWeightedScore();
}


// ─── QuizDetector constructor ─────────────────────────────
QuizDetector::QuizDetector() : totalScore(0), maxPossible(0) {
    // (question text, weight)  — weight=2 means high-impact question
    questions.emplace_back("Do you feel energetic and motivated?",          2);
    questions.emplace_back("Are you smiling or feeling light-hearted?",     1);
    questions.emplace_back("Do you feel calm and at peace right now?",      2);
    questions.emplace_back("Are you free from worry or anxious thoughts?",  2);
    questions.emplace_back("Do you feel connected with people around you?", 1);
    questions.emplace_back("Can you focus and think clearly today?",        1);
    questions.emplace_back("Are you looking forward to what's ahead?",      1);

    for (auto& q : questions)
        maxPossible += q.getMaxScore();
}


// ─── run ─────────────────────────────────────────────────
void QuizDetector::run() {
    totalScore = 0;
    cout << "\n  ╔══════════════════════════════════╗";
    cout << "\n  ║     MOOD QUESTIONNAIRE           ║";
    cout << "\n  ╚══════════════════════════════════╝";

    int idx = 1;
    for (auto& q : questions)
        totalScore += q.ask(idx++);

    float ratio   = (float)totalScore / maxPossible;
    detectedEmotion = mapScoreToEmotion(ratio);
    confidenceScore = (int)(ratio * 100);
}


// ─── mapScoreToEmotion ────────────────────────────────────
string QuizDetector::mapScoreToEmotion(float ratio) const {
    if      (ratio < 0.25f) return "Very Sad";
    else if (ratio < 0.45f) return "Sad";
    else if (ratio < 0.60f) return "Neutral";
    else if (ratio < 0.78f) return "Happy";
    else                    return "Very Happy";
}


// ─── getEmotion ───────────────────────────────────────────
string QuizDetector::getEmotion() {
    return detectedEmotion;
}


// ─── displayResult ────────────────────────────────────────
void QuizDetector::displayResult() {
    float ratio = (float)totalScore / maxPossible;
    int   bar   = (int)(ratio * 30);

    cout << "\n\n  [Quiz Result]";
    cout << "\n  Score   : " << totalScore << " / " << maxPossible;
    cout << "\n  Mood    : " << detectedEmotion;
    cout << "\n  Level   : [";
    for (int i = 0; i < 30; i++) cout << (i < bar ? "█" : "░");
    cout << "] " << fixed << setprecision(0) << ratio * 100 << "%\n";
}
