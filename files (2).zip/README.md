# Emotion Detector — C++ Project
### Concepts: Inheritance · Polymorphism · Abstract Classes · OpenCV

---

## Project Structure

```
emotion_project/
├── main.cpp            ← Entry point
├── Detector.h          ← Abstract base class
├── QuizDetector.h/.cpp ← Text quiz (inherits Detector)
├── FaceDetector.h/.cpp ← OpenCV camera (inherits Detector)
├── EmotionEngine.h/.cpp← Aggregator using polymorphism
├── CMakeLists.txt      ← Build config
└── README.md
```

---

## Class Hierarchy (OOP Design)

```
Detector          ← Abstract Base Class
  |                 (pure virtual: run, getEmotion, displayResult)
  ├── QuizDetector  ← Text-based mood questionnaire
  └── FaceDetector  ← OpenCV Haar Cascade face + smile + eye detection

EmotionEngine     ← Holds vector<Detector*> (polymorphism)
                    Fuses results from all detectors → final emotion

Question          ← Encapsulates one quiz question (weighted scoring)
EmotionProfile    ← Stores name, emoji, advice, ANSI color
```

---

## Key C++ Concepts Used

| Concept | Where |
|---|---|
| Abstract class | `Detector` with pure virtual functions |
| Inheritance | `QuizDetector : Detector`, `FaceDetector : Detector` |
| Polymorphism | `vector<Detector*>` in `EmotionEngine` |
| Virtual destructor | `virtual ~Detector()` in base |
| Encapsulation | Private members + getters in all classes |
| STL `vector` | Questions list, detectors list |
| STL `map` | Emotion profiles lookup |
| Dynamic memory | `new`/`delete` for detectors and profiles |
| OpenCV | Haar Cascades for face, smile, eye detection |

---

## Build Instructions

### Step 1 — Install OpenCV (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install libopencv-dev cmake build-essential
```

### Step 2 — Install OpenCV (macOS)
```bash
brew install opencv cmake
```

### Step 3 — Build with CMake
```bash
mkdir build && cd build
cmake ..
make
./emotion_detector
```

### OR — Build with g++ directly
```bash
g++ main.cpp QuizDetector.cpp FaceDetector.cpp EmotionEngine.cpp \
    -o emotion_detector \
    $(pkg-config --cflags --libs opencv4) \
    -std=c++17
./emotion_detector
```

---

## How It Works

### Quiz Mode
- 7 weighted questions (some count double)
- Score → ratio → emotion mapped to: Very Sad / Sad / Neutral / Happy / Very Happy

### Face Detection Mode
- Opens webcam window
- Detects: face, smile (inside face ROI), eyes (upper 60% of face)
- Live overlay drawn on frame
- Press **Q** to capture final reading

### Fusion Logic (EmotionEngine)
- Face result gets **1.5× weight**, quiz gets **1.0×**
- Weighted average → final emotion
- Final `EmotionProfile` printed with ANSI color

---

## Sample Output

```
  Welcome to the Emotion Detector!
  Enter your name: Aryan

  ╔══════════════════════════════════╗
  ║     MOOD QUESTIONNAIRE           ║
  ╚══════════════════════════════════╝

  [Q1] Do you feel energetic and motivated?
       1=Not at all   3=Moderate   5=Absolutely
       Your answer: 4

  ...

  [Face Detector] Opening camera...
  Camera ready. Press Q to capture.

  ════ FINAL REPORT FOR: Aryan ════

  Individual readings:
    [Quiz] Happy  (confidence 72%)
    [Face] Happy  (confidence 90%)

  ╔══════════════════════════════════════════╗
  ║  ( ^ u ^ )  Emotion  : Happy            ║
  ║  Advice   : Great mood! Spread the      ║
  ║             positivity around you.      ║
  ╚══════════════════════════════════════════╝
```

---

## Cascade XML Paths

Default path used in `main.cpp`:
```
/usr/share/opencv4/haarcascades/haarcascade_frontalface_default.xml
```

If your OpenCV is installed elsewhere, update the constants in `main.cpp`:
```cpp
const string FACE_CASCADE  = "/path/to/haarcascade_frontalface_default.xml";
const string SMILE_CASCADE = "/path/to/haarcascade_smile.xml";
const string EYE_CASCADE   = "/path/to/haarcascade_eye.xml";
```
